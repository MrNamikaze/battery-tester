﻿using System.Windows.Forms;

namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.relay_off1 = new System.Windows.Forms.Label();
            this.relay_off2 = new System.Windows.Forms.Label();
            this.relay_off3 = new System.Windows.Forms.Label();
            this.relay_off4 = new System.Windows.Forms.Label();
            this.relay_off5 = new System.Windows.Forms.Label();
            this.relay_off6 = new System.Windows.Forms.Label();
            this.relay_off7 = new System.Windows.Forms.Label();
            this.relay_off8 = new System.Windows.Forms.Label();
            this.relay_off9 = new System.Windows.Forms.Label();
            this.relay_off10 = new System.Windows.Forms.Label();
            this.relay_on1 = new System.Windows.Forms.Label();
            this.relay_on2 = new System.Windows.Forms.Label();
            this.relay_on3 = new System.Windows.Forms.Label();
            this.relay_on4 = new System.Windows.Forms.Label();
            this.relay_on5 = new System.Windows.Forms.Label();
            this.relay_on6 = new System.Windows.Forms.Label();
            this.relay_on7 = new System.Windows.Forms.Label();
            this.relay_on8 = new System.Windows.Forms.Label();
            this.relay_on9 = new System.Windows.Forms.Label();
            this.relay_on10 = new System.Windows.Forms.Label();
            this.tombol_1 = new System.Windows.Forms.Label();
            this.tombol_2 = new System.Windows.Forms.Label();
            this.tombol_3 = new System.Windows.Forms.Label();
            this.tombol_4 = new System.Windows.Forms.Label();
            this.tombol_5 = new System.Windows.Forms.Label();
            this.tombol_6 = new System.Windows.Forms.Label();
            this.tombol_7 = new System.Windows.Forms.Label();
            this.tombol_8 = new System.Windows.Forms.Label();
            this.tombol_9 = new System.Windows.Forms.Label();
            this.tombol_10 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.jam = new System.Windows.Forms.Label();
            this.penghitung_waktu = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.label4 = new System.Windows.Forms.Label();
            this.relay_off11 = new System.Windows.Forms.Label();
            this.relay_off12 = new System.Windows.Forms.Label();
            this.relay_off13 = new System.Windows.Forms.Label();
            this.relay_off14 = new System.Windows.Forms.Label();
            this.relay_off15 = new System.Windows.Forms.Label();
            this.relay_off16 = new System.Windows.Forms.Label();
            this.relay_on11 = new System.Windows.Forms.Label();
            this.relay_on12 = new System.Windows.Forms.Label();
            this.relay_on13 = new System.Windows.Forms.Label();
            this.relay_on14 = new System.Windows.Forms.Label();
            this.relay_on15 = new System.Windows.Forms.Label();
            this.relay_on16 = new System.Windows.Forms.Label();
            this.tombol_11 = new System.Windows.Forms.Label();
            this.tombol_12 = new System.Windows.Forms.Label();
            this.tombol_13 = new System.Windows.Forms.Label();
            this.tombol_14 = new System.Windows.Forms.Label();
            this.tombol_15 = new System.Windows.Forms.Label();
            this.tombol_16 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.status_relay1 = new System.Windows.Forms.Label();
            this.status_relay2 = new System.Windows.Forms.Label();
            this.status_relay3 = new System.Windows.Forms.Label();
            this.status_relay4 = new System.Windows.Forms.Label();
            this.status_relay5 = new System.Windows.Forms.Label();
            this.status_relay6 = new System.Windows.Forms.Label();
            this.status_relay7 = new System.Windows.Forms.Label();
            this.status_relay8 = new System.Windows.Forms.Label();
            this.status_relay9 = new System.Windows.Forms.Label();
            this.status_relay10 = new System.Windows.Forms.Label();
            this.status_relay11 = new System.Windows.Forms.Label();
            this.status_relay12 = new System.Windows.Forms.Label();
            this.status_relay13 = new System.Windows.Forms.Label();
            this.status_relay14 = new System.Windows.Forms.Label();
            this.status_relay15 = new System.Windows.Forms.Label();
            this.status_relay16 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.namaPath = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.close_program = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.namaFile = new System.Windows.Forms.TextBox();
            this.waktu_berjalan = new System.Windows.Forms.Label();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.label32 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(150, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Arus";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(579, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 37);
            this.label2.TabIndex = 1;
            this.label2.Text = "Volt";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(1013, 298);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 37);
            this.label3.TabIndex = 2;
            this.label3.Text = "Waktu";
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(16, 65);
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Legend = "Legend1";
            series1.Name = "Arus";
            series1.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time;
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(372, 222);
            this.chart1.TabIndex = 3;
            this.chart1.Text = "chart1";
            // 
            // chart2
            // 
            chartArea2.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chart2.Legends.Add(legend2);
            this.chart2.Location = new System.Drawing.Point(432, 65);
            this.chart2.Name = "chart2";
            this.chart2.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Legend = "Legend1";
            series2.Name = "Volt";
            series2.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time;
            this.chart2.Series.Add(series2);
            this.chart2.Size = new System.Drawing.Size(372, 222);
            this.chart2.TabIndex = 4;
            this.chart2.Text = "chart2";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(838, 421);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 31);
            this.button1.TabIndex = 5;
            this.button1.Text = "Start";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1075, 421);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(135, 31);
            this.button2.TabIndex = 6;
            this.button2.Text = "Stop";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // relay_off1
            // 
            this.relay_off1.AutoSize = true;
            this.relay_off1.Image = ((System.Drawing.Image)(resources.GetObject("relay_off1.Image")));
            this.relay_off1.Location = new System.Drawing.Point(22, 549);
            this.relay_off1.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_off1.Name = "relay_off1";
            this.relay_off1.Size = new System.Drawing.Size(65, 65);
            this.relay_off1.TabIndex = 7;
            // 
            // relay_off2
            // 
            this.relay_off2.AutoSize = true;
            this.relay_off2.Image = ((System.Drawing.Image)(resources.GetObject("relay_off2.Image")));
            this.relay_off2.Location = new System.Drawing.Point(93, 551);
            this.relay_off2.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_off2.Name = "relay_off2";
            this.relay_off2.Size = new System.Drawing.Size(65, 65);
            this.relay_off2.TabIndex = 8;
            // 
            // relay_off3
            // 
            this.relay_off3.AutoSize = true;
            this.relay_off3.Image = ((System.Drawing.Image)(resources.GetObject("relay_off3.Image")));
            this.relay_off3.Location = new System.Drawing.Point(164, 550);
            this.relay_off3.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_off3.Name = "relay_off3";
            this.relay_off3.Size = new System.Drawing.Size(65, 65);
            this.relay_off3.TabIndex = 9;
            // 
            // relay_off4
            // 
            this.relay_off4.AutoSize = true;
            this.relay_off4.Image = ((System.Drawing.Image)(resources.GetObject("relay_off4.Image")));
            this.relay_off4.Location = new System.Drawing.Point(235, 551);
            this.relay_off4.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_off4.Name = "relay_off4";
            this.relay_off4.Size = new System.Drawing.Size(65, 65);
            this.relay_off4.TabIndex = 10;
            // 
            // relay_off5
            // 
            this.relay_off5.AutoSize = true;
            this.relay_off5.Image = ((System.Drawing.Image)(resources.GetObject("relay_off5.Image")));
            this.relay_off5.Location = new System.Drawing.Point(306, 551);
            this.relay_off5.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_off5.Name = "relay_off5";
            this.relay_off5.Size = new System.Drawing.Size(65, 65);
            this.relay_off5.TabIndex = 11;
            // 
            // relay_off6
            // 
            this.relay_off6.AutoSize = true;
            this.relay_off6.Image = ((System.Drawing.Image)(resources.GetObject("relay_off6.Image")));
            this.relay_off6.Location = new System.Drawing.Point(377, 551);
            this.relay_off6.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_off6.Name = "relay_off6";
            this.relay_off6.Size = new System.Drawing.Size(65, 65);
            this.relay_off6.TabIndex = 12;
            // 
            // relay_off7
            // 
            this.relay_off7.AutoSize = true;
            this.relay_off7.Image = ((System.Drawing.Image)(resources.GetObject("relay_off7.Image")));
            this.relay_off7.Location = new System.Drawing.Point(448, 551);
            this.relay_off7.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_off7.Name = "relay_off7";
            this.relay_off7.Size = new System.Drawing.Size(65, 65);
            this.relay_off7.TabIndex = 13;
            // 
            // relay_off8
            // 
            this.relay_off8.AutoSize = true;
            this.relay_off8.Image = ((System.Drawing.Image)(resources.GetObject("relay_off8.Image")));
            this.relay_off8.Location = new System.Drawing.Point(519, 551);
            this.relay_off8.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_off8.Name = "relay_off8";
            this.relay_off8.Size = new System.Drawing.Size(65, 65);
            this.relay_off8.TabIndex = 14;
            // 
            // relay_off9
            // 
            this.relay_off9.AutoSize = true;
            this.relay_off9.Image = ((System.Drawing.Image)(resources.GetObject("relay_off9.Image")));
            this.relay_off9.Location = new System.Drawing.Point(590, 551);
            this.relay_off9.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_off9.Name = "relay_off9";
            this.relay_off9.Size = new System.Drawing.Size(65, 65);
            this.relay_off9.TabIndex = 15;
            // 
            // relay_off10
            // 
            this.relay_off10.AutoSize = true;
            this.relay_off10.Image = ((System.Drawing.Image)(resources.GetObject("relay_off10.Image")));
            this.relay_off10.Location = new System.Drawing.Point(662, 551);
            this.relay_off10.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_off10.Name = "relay_off10";
            this.relay_off10.Size = new System.Drawing.Size(65, 65);
            this.relay_off10.TabIndex = 16;
            // 
            // relay_on1
            // 
            this.relay_on1.AutoSize = true;
            this.relay_on1.Image = ((System.Drawing.Image)(resources.GetObject("relay_on1.Image")));
            this.relay_on1.Location = new System.Drawing.Point(22, 550);
            this.relay_on1.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_on1.Name = "relay_on1";
            this.relay_on1.Size = new System.Drawing.Size(65, 65);
            this.relay_on1.TabIndex = 17;
            this.relay_on1.Visible = false;
            // 
            // relay_on2
            // 
            this.relay_on2.AutoSize = true;
            this.relay_on2.Image = ((System.Drawing.Image)(resources.GetObject("relay_on2.Image")));
            this.relay_on2.Location = new System.Drawing.Point(93, 552);
            this.relay_on2.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_on2.Name = "relay_on2";
            this.relay_on2.Size = new System.Drawing.Size(65, 65);
            this.relay_on2.TabIndex = 18;
            this.relay_on2.Visible = false;
            // 
            // relay_on3
            // 
            this.relay_on3.AutoSize = true;
            this.relay_on3.Image = ((System.Drawing.Image)(resources.GetObject("relay_on3.Image")));
            this.relay_on3.Location = new System.Drawing.Point(164, 551);
            this.relay_on3.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_on3.Name = "relay_on3";
            this.relay_on3.Size = new System.Drawing.Size(65, 65);
            this.relay_on3.TabIndex = 19;
            this.relay_on3.Visible = false;
            // 
            // relay_on4
            // 
            this.relay_on4.AutoSize = true;
            this.relay_on4.Image = ((System.Drawing.Image)(resources.GetObject("relay_on4.Image")));
            this.relay_on4.Location = new System.Drawing.Point(235, 552);
            this.relay_on4.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_on4.Name = "relay_on4";
            this.relay_on4.Size = new System.Drawing.Size(65, 65);
            this.relay_on4.TabIndex = 20;
            this.relay_on4.Visible = false;
            // 
            // relay_on5
            // 
            this.relay_on5.AutoSize = true;
            this.relay_on5.Image = ((System.Drawing.Image)(resources.GetObject("relay_on5.Image")));
            this.relay_on5.Location = new System.Drawing.Point(306, 552);
            this.relay_on5.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_on5.Name = "relay_on5";
            this.relay_on5.Size = new System.Drawing.Size(65, 65);
            this.relay_on5.TabIndex = 21;
            this.relay_on5.Visible = false;
            // 
            // relay_on6
            // 
            this.relay_on6.AutoSize = true;
            this.relay_on6.Image = ((System.Drawing.Image)(resources.GetObject("relay_on6.Image")));
            this.relay_on6.Location = new System.Drawing.Point(377, 552);
            this.relay_on6.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_on6.Name = "relay_on6";
            this.relay_on6.Size = new System.Drawing.Size(65, 65);
            this.relay_on6.TabIndex = 22;
            this.relay_on6.Visible = false;
            // 
            // relay_on7
            // 
            this.relay_on7.AutoSize = true;
            this.relay_on7.Image = ((System.Drawing.Image)(resources.GetObject("relay_on7.Image")));
            this.relay_on7.Location = new System.Drawing.Point(448, 552);
            this.relay_on7.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_on7.Name = "relay_on7";
            this.relay_on7.Size = new System.Drawing.Size(65, 65);
            this.relay_on7.TabIndex = 23;
            this.relay_on7.Visible = false;
            // 
            // relay_on8
            // 
            this.relay_on8.AutoSize = true;
            this.relay_on8.Image = ((System.Drawing.Image)(resources.GetObject("relay_on8.Image")));
            this.relay_on8.Location = new System.Drawing.Point(519, 552);
            this.relay_on8.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_on8.Name = "relay_on8";
            this.relay_on8.Size = new System.Drawing.Size(65, 65);
            this.relay_on8.TabIndex = 24;
            this.relay_on8.Visible = false;
            // 
            // relay_on9
            // 
            this.relay_on9.AutoSize = true;
            this.relay_on9.Image = ((System.Drawing.Image)(resources.GetObject("relay_on9.Image")));
            this.relay_on9.Location = new System.Drawing.Point(590, 552);
            this.relay_on9.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_on9.Name = "relay_on9";
            this.relay_on9.Size = new System.Drawing.Size(65, 65);
            this.relay_on9.TabIndex = 25;
            this.relay_on9.Visible = false;
            // 
            // relay_on10
            // 
            this.relay_on10.AutoSize = true;
            this.relay_on10.Image = ((System.Drawing.Image)(resources.GetObject("relay_on10.Image")));
            this.relay_on10.Location = new System.Drawing.Point(662, 552);
            this.relay_on10.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_on10.Name = "relay_on10";
            this.relay_on10.Size = new System.Drawing.Size(65, 65);
            this.relay_on10.TabIndex = 26;
            this.relay_on10.Visible = false;
            // 
            // tombol_1
            // 
            this.tombol_1.AutoSize = true;
            this.tombol_1.Image = ((System.Drawing.Image)(resources.GetObject("tombol_1.Image")));
            this.tombol_1.Location = new System.Drawing.Point(22, 639);
            this.tombol_1.MinimumSize = new System.Drawing.Size(65, 65);
            this.tombol_1.Name = "tombol_1";
            this.tombol_1.Size = new System.Drawing.Size(65, 65);
            this.tombol_1.TabIndex = 27;
            this.tombol_1.Click += new System.EventHandler(this.tombol_1_Click);
            // 
            // tombol_2
            // 
            this.tombol_2.AutoSize = true;
            this.tombol_2.Cursor = System.Windows.Forms.Cursors.Default;
            this.tombol_2.Image = ((System.Drawing.Image)(resources.GetObject("tombol_2.Image")));
            this.tombol_2.Location = new System.Drawing.Point(93, 641);
            this.tombol_2.MinimumSize = new System.Drawing.Size(65, 65);
            this.tombol_2.Name = "tombol_2";
            this.tombol_2.Size = new System.Drawing.Size(65, 65);
            this.tombol_2.TabIndex = 28;
            this.tombol_2.Click += new System.EventHandler(this.tombol_2_Click);
            // 
            // tombol_3
            // 
            this.tombol_3.AutoSize = true;
            this.tombol_3.Image = ((System.Drawing.Image)(resources.GetObject("tombol_3.Image")));
            this.tombol_3.Location = new System.Drawing.Point(164, 640);
            this.tombol_3.MinimumSize = new System.Drawing.Size(65, 65);
            this.tombol_3.Name = "tombol_3";
            this.tombol_3.Size = new System.Drawing.Size(65, 65);
            this.tombol_3.TabIndex = 29;
            this.tombol_3.Click += new System.EventHandler(this.tombol_3_Click);
            // 
            // tombol_4
            // 
            this.tombol_4.AutoSize = true;
            this.tombol_4.Image = ((System.Drawing.Image)(resources.GetObject("tombol_4.Image")));
            this.tombol_4.Location = new System.Drawing.Point(235, 641);
            this.tombol_4.MinimumSize = new System.Drawing.Size(65, 65);
            this.tombol_4.Name = "tombol_4";
            this.tombol_4.Size = new System.Drawing.Size(65, 65);
            this.tombol_4.TabIndex = 30;
            this.tombol_4.Click += new System.EventHandler(this.tombol_4_Click);
            // 
            // tombol_5
            // 
            this.tombol_5.AutoSize = true;
            this.tombol_5.Image = ((System.Drawing.Image)(resources.GetObject("tombol_5.Image")));
            this.tombol_5.Location = new System.Drawing.Point(306, 641);
            this.tombol_5.MinimumSize = new System.Drawing.Size(65, 65);
            this.tombol_5.Name = "tombol_5";
            this.tombol_5.Size = new System.Drawing.Size(65, 65);
            this.tombol_5.TabIndex = 31;
            this.tombol_5.Click += new System.EventHandler(this.tombol_5_Click);
            // 
            // tombol_6
            // 
            this.tombol_6.AutoSize = true;
            this.tombol_6.Image = ((System.Drawing.Image)(resources.GetObject("tombol_6.Image")));
            this.tombol_6.Location = new System.Drawing.Point(377, 641);
            this.tombol_6.MinimumSize = new System.Drawing.Size(65, 65);
            this.tombol_6.Name = "tombol_6";
            this.tombol_6.Size = new System.Drawing.Size(65, 65);
            this.tombol_6.TabIndex = 32;
            this.tombol_6.Click += new System.EventHandler(this.tombol_6_Click);
            // 
            // tombol_7
            // 
            this.tombol_7.AutoSize = true;
            this.tombol_7.Image = ((System.Drawing.Image)(resources.GetObject("tombol_7.Image")));
            this.tombol_7.Location = new System.Drawing.Point(448, 641);
            this.tombol_7.MinimumSize = new System.Drawing.Size(65, 65);
            this.tombol_7.Name = "tombol_7";
            this.tombol_7.Size = new System.Drawing.Size(65, 65);
            this.tombol_7.TabIndex = 33;
            this.tombol_7.Click += new System.EventHandler(this.tombol_7_Click);
            // 
            // tombol_8
            // 
            this.tombol_8.AutoSize = true;
            this.tombol_8.Image = ((System.Drawing.Image)(resources.GetObject("tombol_8.Image")));
            this.tombol_8.Location = new System.Drawing.Point(519, 641);
            this.tombol_8.MinimumSize = new System.Drawing.Size(65, 65);
            this.tombol_8.Name = "tombol_8";
            this.tombol_8.Size = new System.Drawing.Size(65, 65);
            this.tombol_8.TabIndex = 34;
            this.tombol_8.Click += new System.EventHandler(this.tombol_8_Click);
            // 
            // tombol_9
            // 
            this.tombol_9.AutoSize = true;
            this.tombol_9.Image = ((System.Drawing.Image)(resources.GetObject("tombol_9.Image")));
            this.tombol_9.Location = new System.Drawing.Point(590, 641);
            this.tombol_9.MinimumSize = new System.Drawing.Size(65, 65);
            this.tombol_9.Name = "tombol_9";
            this.tombol_9.Size = new System.Drawing.Size(65, 65);
            this.tombol_9.TabIndex = 35;
            this.tombol_9.Click += new System.EventHandler(this.tombol_9_Click);
            // 
            // tombol_10
            // 
            this.tombol_10.AutoSize = true;
            this.tombol_10.Image = ((System.Drawing.Image)(resources.GetObject("tombol_10.Image")));
            this.tombol_10.Location = new System.Drawing.Point(662, 641);
            this.tombol_10.MinimumSize = new System.Drawing.Size(65, 65);
            this.tombol_10.Name = "tombol_10";
            this.tombol_10.Size = new System.Drawing.Size(65, 65);
            this.tombol_10.TabIndex = 36;
            this.tombol_10.Click += new System.EventHandler(this.tombol_10_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // jam
            // 
            this.jam.AutoSize = true;
            this.jam.Location = new System.Drawing.Point(841, 331);
            this.jam.Name = "jam";
            this.jam.Size = new System.Drawing.Size(0, 13);
            this.jam.TabIndex = 37;
            // 
            // penghitung_waktu
            // 
            this.penghitung_waktu.AutoSize = true;
            this.penghitung_waktu.Location = new System.Drawing.Point(1001, 170);
            this.penghitung_waktu.Name = "penghitung_waktu";
            this.penghitung_waktu.Size = new System.Drawing.Size(0, 13);
            this.penghitung_waktu.TabIndex = 38;
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(25, 497);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 20);
            this.label4.TabIndex = 39;
            this.label4.Text = "Relay 1";
            // 
            // relay_off11
            // 
            this.relay_off11.AutoSize = true;
            this.relay_off11.Image = ((System.Drawing.Image)(resources.GetObject("relay_off11.Image")));
            this.relay_off11.Location = new System.Drawing.Point(739, 552);
            this.relay_off11.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_off11.Name = "relay_off11";
            this.relay_off11.Size = new System.Drawing.Size(65, 65);
            this.relay_off11.TabIndex = 40;
            // 
            // relay_off12
            // 
            this.relay_off12.AutoSize = true;
            this.relay_off12.Image = ((System.Drawing.Image)(resources.GetObject("relay_off12.Image")));
            this.relay_off12.Location = new System.Drawing.Point(816, 552);
            this.relay_off12.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_off12.Name = "relay_off12";
            this.relay_off12.Size = new System.Drawing.Size(65, 65);
            this.relay_off12.TabIndex = 41;
            // 
            // relay_off13
            // 
            this.relay_off13.AutoSize = true;
            this.relay_off13.Image = ((System.Drawing.Image)(resources.GetObject("relay_off13.Image")));
            this.relay_off13.Location = new System.Drawing.Point(897, 552);
            this.relay_off13.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_off13.Name = "relay_off13";
            this.relay_off13.Size = new System.Drawing.Size(65, 65);
            this.relay_off13.TabIndex = 42;
            // 
            // relay_off14
            // 
            this.relay_off14.AutoSize = true;
            this.relay_off14.Image = ((System.Drawing.Image)(resources.GetObject("relay_off14.Image")));
            this.relay_off14.Location = new System.Drawing.Point(975, 552);
            this.relay_off14.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_off14.Name = "relay_off14";
            this.relay_off14.Size = new System.Drawing.Size(65, 65);
            this.relay_off14.TabIndex = 43;
            // 
            // relay_off15
            // 
            this.relay_off15.AutoSize = true;
            this.relay_off15.Image = ((System.Drawing.Image)(resources.GetObject("relay_off15.Image")));
            this.relay_off15.Location = new System.Drawing.Point(1052, 551);
            this.relay_off15.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_off15.Name = "relay_off15";
            this.relay_off15.Size = new System.Drawing.Size(65, 65);
            this.relay_off15.TabIndex = 44;
            // 
            // relay_off16
            // 
            this.relay_off16.AutoSize = true;
            this.relay_off16.Image = ((System.Drawing.Image)(resources.GetObject("relay_off16.Image")));
            this.relay_off16.Location = new System.Drawing.Point(1131, 552);
            this.relay_off16.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_off16.Name = "relay_off16";
            this.relay_off16.Size = new System.Drawing.Size(65, 65);
            this.relay_off16.TabIndex = 45;
            // 
            // relay_on11
            // 
            this.relay_on11.AutoSize = true;
            this.relay_on11.Image = ((System.Drawing.Image)(resources.GetObject("relay_on11.Image")));
            this.relay_on11.Location = new System.Drawing.Point(739, 552);
            this.relay_on11.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_on11.Name = "relay_on11";
            this.relay_on11.Size = new System.Drawing.Size(65, 65);
            this.relay_on11.TabIndex = 46;
            this.relay_on11.Visible = false;
            // 
            // relay_on12
            // 
            this.relay_on12.AutoSize = true;
            this.relay_on12.Image = ((System.Drawing.Image)(resources.GetObject("relay_on12.Image")));
            this.relay_on12.Location = new System.Drawing.Point(816, 552);
            this.relay_on12.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_on12.Name = "relay_on12";
            this.relay_on12.Size = new System.Drawing.Size(65, 65);
            this.relay_on12.TabIndex = 47;
            this.relay_on12.Visible = false;
            // 
            // relay_on13
            // 
            this.relay_on13.AutoSize = true;
            this.relay_on13.Image = ((System.Drawing.Image)(resources.GetObject("relay_on13.Image")));
            this.relay_on13.Location = new System.Drawing.Point(897, 552);
            this.relay_on13.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_on13.Name = "relay_on13";
            this.relay_on13.Size = new System.Drawing.Size(65, 65);
            this.relay_on13.TabIndex = 48;
            this.relay_on13.Visible = false;
            // 
            // relay_on14
            // 
            this.relay_on14.AutoSize = true;
            this.relay_on14.Image = ((System.Drawing.Image)(resources.GetObject("relay_on14.Image")));
            this.relay_on14.Location = new System.Drawing.Point(975, 552);
            this.relay_on14.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_on14.Name = "relay_on14";
            this.relay_on14.Size = new System.Drawing.Size(65, 65);
            this.relay_on14.TabIndex = 49;
            this.relay_on14.Visible = false;
            // 
            // relay_on15
            // 
            this.relay_on15.AutoSize = true;
            this.relay_on15.Image = ((System.Drawing.Image)(resources.GetObject("relay_on15.Image")));
            this.relay_on15.Location = new System.Drawing.Point(1052, 552);
            this.relay_on15.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_on15.Name = "relay_on15";
            this.relay_on15.Size = new System.Drawing.Size(65, 65);
            this.relay_on15.TabIndex = 50;
            this.relay_on15.Visible = false;
            // 
            // relay_on16
            // 
            this.relay_on16.AutoSize = true;
            this.relay_on16.Image = ((System.Drawing.Image)(resources.GetObject("relay_on16.Image")));
            this.relay_on16.Location = new System.Drawing.Point(1131, 552);
            this.relay_on16.MinimumSize = new System.Drawing.Size(65, 65);
            this.relay_on16.Name = "relay_on16";
            this.relay_on16.Size = new System.Drawing.Size(65, 65);
            this.relay_on16.TabIndex = 51;
            this.relay_on16.Visible = false;
            // 
            // tombol_11
            // 
            this.tombol_11.AutoSize = true;
            this.tombol_11.Image = ((System.Drawing.Image)(resources.GetObject("tombol_11.Image")));
            this.tombol_11.Location = new System.Drawing.Point(739, 641);
            this.tombol_11.MinimumSize = new System.Drawing.Size(65, 65);
            this.tombol_11.Name = "tombol_11";
            this.tombol_11.Size = new System.Drawing.Size(65, 65);
            this.tombol_11.TabIndex = 52;
            this.tombol_11.Click += new System.EventHandler(this.tombol_11_Click);
            // 
            // tombol_12
            // 
            this.tombol_12.AutoSize = true;
            this.tombol_12.Image = ((System.Drawing.Image)(resources.GetObject("tombol_12.Image")));
            this.tombol_12.Location = new System.Drawing.Point(816, 641);
            this.tombol_12.MinimumSize = new System.Drawing.Size(65, 65);
            this.tombol_12.Name = "tombol_12";
            this.tombol_12.Size = new System.Drawing.Size(65, 65);
            this.tombol_12.TabIndex = 53;
            this.tombol_12.Click += new System.EventHandler(this.tombol_12_Click);
            // 
            // tombol_13
            // 
            this.tombol_13.AutoSize = true;
            this.tombol_13.Image = ((System.Drawing.Image)(resources.GetObject("tombol_13.Image")));
            this.tombol_13.Location = new System.Drawing.Point(897, 641);
            this.tombol_13.MinimumSize = new System.Drawing.Size(65, 65);
            this.tombol_13.Name = "tombol_13";
            this.tombol_13.Size = new System.Drawing.Size(65, 65);
            this.tombol_13.TabIndex = 54;
            this.tombol_13.Click += new System.EventHandler(this.tombol_13_Click);
            // 
            // tombol_14
            // 
            this.tombol_14.AutoSize = true;
            this.tombol_14.Image = ((System.Drawing.Image)(resources.GetObject("tombol_14.Image")));
            this.tombol_14.Location = new System.Drawing.Point(975, 641);
            this.tombol_14.MinimumSize = new System.Drawing.Size(65, 65);
            this.tombol_14.Name = "tombol_14";
            this.tombol_14.Size = new System.Drawing.Size(65, 65);
            this.tombol_14.TabIndex = 55;
            this.tombol_14.Click += new System.EventHandler(this.tombol_14_Click);
            // 
            // tombol_15
            // 
            this.tombol_15.AutoSize = true;
            this.tombol_15.Image = ((System.Drawing.Image)(resources.GetObject("tombol_15.Image")));
            this.tombol_15.Location = new System.Drawing.Point(1052, 641);
            this.tombol_15.MinimumSize = new System.Drawing.Size(65, 65);
            this.tombol_15.Name = "tombol_15";
            this.tombol_15.Size = new System.Drawing.Size(65, 65);
            this.tombol_15.TabIndex = 56;
            this.tombol_15.Click += new System.EventHandler(this.tombol_15_Click);
            // 
            // tombol_16
            // 
            this.tombol_16.AutoSize = true;
            this.tombol_16.Image = ((System.Drawing.Image)(resources.GetObject("tombol_16.Image")));
            this.tombol_16.Location = new System.Drawing.Point(1131, 641);
            this.tombol_16.MinimumSize = new System.Drawing.Size(65, 65);
            this.tombol_16.Name = "tombol_16";
            this.tombol_16.Size = new System.Drawing.Size(65, 65);
            this.tombol_16.TabIndex = 57;
            this.tombol_16.Click += new System.EventHandler(this.tombol_16_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.Location = new System.Drawing.Point(96, 497);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 20);
            this.label5.TabIndex = 58;
            this.label5.Text = "Relay 2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label6.Location = new System.Drawing.Point(167, 497);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 20);
            this.label6.TabIndex = 59;
            this.label6.Text = "Relay 3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label7.Location = new System.Drawing.Point(238, 497);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 20);
            this.label7.TabIndex = 60;
            this.label7.Text = "Relay 4";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label8.Location = new System.Drawing.Point(309, 497);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 20);
            this.label8.TabIndex = 61;
            this.label8.Text = "Relay 5";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label9.Location = new System.Drawing.Point(376, 497);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 20);
            this.label9.TabIndex = 62;
            this.label9.Text = "Relay 6";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label10.Location = new System.Drawing.Point(447, 497);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 20);
            this.label10.TabIndex = 63;
            this.label10.Text = "Relay 7";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label11.Location = new System.Drawing.Point(518, 497);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(62, 20);
            this.label11.TabIndex = 64;
            this.label11.Text = "Relay 8";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label12.Location = new System.Drawing.Point(589, 497);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(62, 20);
            this.label12.TabIndex = 65;
            this.label12.Text = "Relay 9";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label13.Location = new System.Drawing.Point(661, 497);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 20);
            this.label13.TabIndex = 66;
            this.label13.Text = "Relay 10";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label14.Location = new System.Drawing.Point(738, 496);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(71, 20);
            this.label14.TabIndex = 67;
            this.label14.Text = "Relay 11";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label15.Location = new System.Drawing.Point(815, 497);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(75, 20);
            this.label15.TabIndex = 68;
            this.label15.Text = "Relay  12";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label16.Location = new System.Drawing.Point(896, 497);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 20);
            this.label16.TabIndex = 69;
            this.label16.Text = "Relay 13";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label17.Location = new System.Drawing.Point(974, 497);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(71, 20);
            this.label17.TabIndex = 70;
            this.label17.Text = "Relay 14";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label18.Location = new System.Drawing.Point(1051, 497);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(71, 20);
            this.label18.TabIndex = 71;
            this.label18.Text = "Relay 15";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label19.Location = new System.Drawing.Point(1128, 497);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(71, 20);
            this.label19.TabIndex = 72;
            this.label19.Text = "Relay 16";
            // 
            // status_relay1
            // 
            this.status_relay1.AutoSize = true;
            this.status_relay1.Location = new System.Drawing.Point(44, 526);
            this.status_relay1.Name = "status_relay1";
            this.status_relay1.Size = new System.Drawing.Size(21, 13);
            this.status_relay1.TabIndex = 73;
            this.status_relay1.Text = "Off";
            // 
            // status_relay2
            // 
            this.status_relay2.AutoSize = true;
            this.status_relay2.Location = new System.Drawing.Point(116, 526);
            this.status_relay2.Name = "status_relay2";
            this.status_relay2.Size = new System.Drawing.Size(21, 13);
            this.status_relay2.TabIndex = 74;
            this.status_relay2.Text = "Off";
            // 
            // status_relay3
            // 
            this.status_relay3.AutoSize = true;
            this.status_relay3.Location = new System.Drawing.Point(188, 526);
            this.status_relay3.Name = "status_relay3";
            this.status_relay3.Size = new System.Drawing.Size(21, 13);
            this.status_relay3.TabIndex = 75;
            this.status_relay3.Text = "Off";
            // 
            // status_relay4
            // 
            this.status_relay4.AutoSize = true;
            this.status_relay4.Location = new System.Drawing.Point(261, 526);
            this.status_relay4.Name = "status_relay4";
            this.status_relay4.Size = new System.Drawing.Size(21, 13);
            this.status_relay4.TabIndex = 76;
            this.status_relay4.Text = "Off";
            // 
            // status_relay5
            // 
            this.status_relay5.AutoSize = true;
            this.status_relay5.Location = new System.Drawing.Point(328, 526);
            this.status_relay5.Name = "status_relay5";
            this.status_relay5.Size = new System.Drawing.Size(21, 13);
            this.status_relay5.TabIndex = 77;
            this.status_relay5.Text = "Off";
            // 
            // status_relay6
            // 
            this.status_relay6.AutoSize = true;
            this.status_relay6.Location = new System.Drawing.Point(399, 526);
            this.status_relay6.Name = "status_relay6";
            this.status_relay6.Size = new System.Drawing.Size(21, 13);
            this.status_relay6.TabIndex = 78;
            this.status_relay6.Text = "Off";
            // 
            // status_relay7
            // 
            this.status_relay7.AutoSize = true;
            this.status_relay7.Location = new System.Drawing.Point(472, 526);
            this.status_relay7.Name = "status_relay7";
            this.status_relay7.Size = new System.Drawing.Size(21, 13);
            this.status_relay7.TabIndex = 79;
            this.status_relay7.Text = "Off";
            // 
            // status_relay8
            // 
            this.status_relay8.AutoSize = true;
            this.status_relay8.Location = new System.Drawing.Point(540, 526);
            this.status_relay8.Name = "status_relay8";
            this.status_relay8.Size = new System.Drawing.Size(21, 13);
            this.status_relay8.TabIndex = 80;
            this.status_relay8.Text = "Off";
            // 
            // status_relay9
            // 
            this.status_relay9.AutoSize = true;
            this.status_relay9.Location = new System.Drawing.Point(611, 526);
            this.status_relay9.Name = "status_relay9";
            this.status_relay9.Size = new System.Drawing.Size(21, 13);
            this.status_relay9.TabIndex = 81;
            this.status_relay9.Text = "Off";
            // 
            // status_relay10
            // 
            this.status_relay10.AutoSize = true;
            this.status_relay10.Location = new System.Drawing.Point(686, 526);
            this.status_relay10.Name = "status_relay10";
            this.status_relay10.Size = new System.Drawing.Size(21, 13);
            this.status_relay10.TabIndex = 82;
            this.status_relay10.Text = "Off";
            // 
            // status_relay11
            // 
            this.status_relay11.AutoSize = true;
            this.status_relay11.Location = new System.Drawing.Point(761, 525);
            this.status_relay11.Name = "status_relay11";
            this.status_relay11.Size = new System.Drawing.Size(21, 13);
            this.status_relay11.TabIndex = 83;
            this.status_relay11.Text = "Off";
            // 
            // status_relay12
            // 
            this.status_relay12.AutoSize = true;
            this.status_relay12.Location = new System.Drawing.Point(842, 526);
            this.status_relay12.Name = "status_relay12";
            this.status_relay12.Size = new System.Drawing.Size(21, 13);
            this.status_relay12.TabIndex = 84;
            this.status_relay12.Text = "Off";
            // 
            // status_relay13
            // 
            this.status_relay13.AutoSize = true;
            this.status_relay13.Location = new System.Drawing.Point(920, 526);
            this.status_relay13.Name = "status_relay13";
            this.status_relay13.Size = new System.Drawing.Size(21, 13);
            this.status_relay13.TabIndex = 85;
            this.status_relay13.Text = "Off";
            // 
            // status_relay14
            // 
            this.status_relay14.AutoSize = true;
            this.status_relay14.Location = new System.Drawing.Point(996, 526);
            this.status_relay14.Name = "status_relay14";
            this.status_relay14.Size = new System.Drawing.Size(21, 13);
            this.status_relay14.TabIndex = 86;
            this.status_relay14.Text = "Off";
            // 
            // status_relay15
            // 
            this.status_relay15.AutoSize = true;
            this.status_relay15.Location = new System.Drawing.Point(1072, 526);
            this.status_relay15.Name = "status_relay15";
            this.status_relay15.Size = new System.Drawing.Size(21, 13);
            this.status_relay15.TabIndex = 87;
            this.status_relay15.Text = "Off";
            // 
            // status_relay16
            // 
            this.status_relay16.AutoSize = true;
            this.status_relay16.Location = new System.Drawing.Point(1153, 526);
            this.status_relay16.Name = "status_relay16";
            this.status_relay16.Size = new System.Drawing.Size(21, 13);
            this.status_relay16.TabIndex = 88;
            this.status_relay16.Text = "Off";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "string[] ports = SerialPort.GetPortNames();",
            "            String nama_port;",
            "            foreach (string port in ports)",
            "            {",
            "                nama_port = port;",
            "                ",
            "            }"});
            this.comboBox1.Location = new System.Drawing.Point(100, 352);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(288, 21);
            this.comboBox1.TabIndex = 89;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(13, 354);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(26, 13);
            this.label20.TabIndex = 91;
            this.label20.Text = "Port";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(13, 409);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(64, 13);
            this.label21.TabIndex = 92;
            this.label21.Text = "Interval (ms)";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.label22.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label22.Location = new System.Drawing.Point(150, 298);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(116, 37);
            this.label22.TabIndex = 93;
            this.label22.Text = "Setting";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(16, 446);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(121, 30);
            this.button3.TabIndex = 94;
            this.button3.Text = "Open Port";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(100, 406);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(288, 20);
            this.textBox1.TabIndex = 95;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(176, 47);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(0, 13);
            this.label23.TabIndex = 96;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(603, 49);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(0, 13);
            this.label24.TabIndex = 97;
            // 
            // namaPath
            // 
            this.namaPath.Location = new System.Drawing.Point(922, 353);
            this.namaPath.Name = "namaPath";
            this.namaPath.Size = new System.Drawing.Size(288, 20);
            this.namaPath.TabIndex = 99;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(375, 19);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(13, 13);
            this.label25.TabIndex = 100;
            this.label25.Text = "a";
            this.label25.Visible = false;
            // 
            // close_program
            // 
            this.close_program.AutoSize = true;
            this.close_program.Location = new System.Drawing.Point(306, 19);
            this.close_program.Name = "close_program";
            this.close_program.Size = new System.Drawing.Size(13, 13);
            this.close_program.TabIndex = 101;
            this.close_program.Text = "a";
            this.close_program.Visible = false;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label26.Location = new System.Drawing.Point(832, 353);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(42, 20);
            this.label26.TabIndex = 102;
            this.label26.Text = "Path";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label27.Location = new System.Drawing.Point(834, 387);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(82, 20);
            this.label27.TabIndex = 103;
            this.label27.Text = "Nama FIle";
            // 
            // namaFile
            // 
            this.namaFile.Location = new System.Drawing.Point(922, 387);
            this.namaFile.Name = "namaFile";
            this.namaFile.Size = new System.Drawing.Size(288, 20);
            this.namaFile.TabIndex = 104;
            // 
            // waktu_berjalan
            // 
            this.waktu_berjalan.AutoSize = true;
            this.waktu_berjalan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.waktu_berjalan.Location = new System.Drawing.Point(944, 463);
            this.waktu_berjalan.MinimumSize = new System.Drawing.Size(200, 24);
            this.waktu_berjalan.Name = "waktu_berjalan";
            this.waktu_berjalan.Size = new System.Drawing.Size(200, 24);
            this.waktu_berjalan.TabIndex = 105;
            this.waktu_berjalan.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // chart3
            // 
            chartArea3.Name = "ChartArea1";
            this.chart3.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.chart3.Legends.Add(legend3);
            this.chart3.Location = new System.Drawing.Point(838, 65);
            this.chart3.Name = "chart3";
            this.chart3.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.Legend = "Legend1";
            series3.Name = "Temp";
            series3.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time;
            this.chart3.Series.Add(series3);
            this.chart3.Size = new System.Drawing.Size(372, 222);
            this.chart3.TabIndex = 106;
            this.chart3.Text = "chart3";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.label28.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label28.Location = new System.Drawing.Point(992, 9);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(99, 37);
            this.label28.TabIndex = 107;
            this.label28.Text = "Temp";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(1031, 49);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(0, 13);
            this.label29.TabIndex = 108;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "4800",
            "9600",
            "115200"});
            this.comboBox2.Location = new System.Drawing.Point(100, 379);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(288, 21);
            this.comboBox2.TabIndex = 109;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(13, 382);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(55, 13);
            this.label30.TabIndex = 110;
            this.label30.Text = "BaudRate";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.label31.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label31.Location = new System.Drawing.Point(563, 298);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(89, 37);
            this.label31.TabIndex = 111;
            this.label31.Text = "Load";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(264, 446);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(124, 30);
            this.button5.TabIndex = 113;
            this.button5.Text = "Close Port";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(573, 357);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(47, 17);
            this.radioButton1.TabIndex = 114;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "12 A";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(630, 358);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(47, 17);
            this.radioButton2.TabIndex = 115;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "30 A";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(683, 358);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(47, 17);
            this.radioButton3.TabIndex = 116;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "47 A";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(499, 358);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(57, 13);
            this.label32.TabIndex = 117;
            this.label32.Text = "Nilai Load:";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(507, 409);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(96, 23);
            this.button4.TabIndex = 118;
            this.button4.Text = "Kirim";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(641, 409);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(85, 23);
            this.button6.TabIndex = 119;
            this.button6.Text = "Reset";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(143, 446);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(115, 30);
            this.button7.TabIndex = 120;
            this.button7.Text = "Scan Port";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(509, 450);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 121;
            this.button8.Text = "button8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1222, 733);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.chart3);
            this.Controls.Add(this.waktu_berjalan);
            this.Controls.Add(this.namaFile);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.close_program);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.namaPath);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.status_relay16);
            this.Controls.Add(this.status_relay15);
            this.Controls.Add(this.status_relay14);
            this.Controls.Add(this.status_relay13);
            this.Controls.Add(this.status_relay12);
            this.Controls.Add(this.status_relay11);
            this.Controls.Add(this.status_relay10);
            this.Controls.Add(this.status_relay9);
            this.Controls.Add(this.status_relay8);
            this.Controls.Add(this.status_relay7);
            this.Controls.Add(this.status_relay6);
            this.Controls.Add(this.status_relay5);
            this.Controls.Add(this.status_relay4);
            this.Controls.Add(this.status_relay3);
            this.Controls.Add(this.status_relay2);
            this.Controls.Add(this.status_relay1);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tombol_16);
            this.Controls.Add(this.tombol_15);
            this.Controls.Add(this.tombol_14);
            this.Controls.Add(this.tombol_13);
            this.Controls.Add(this.tombol_12);
            this.Controls.Add(this.tombol_11);
            this.Controls.Add(this.relay_on16);
            this.Controls.Add(this.relay_on15);
            this.Controls.Add(this.relay_on14);
            this.Controls.Add(this.relay_on13);
            this.Controls.Add(this.relay_on12);
            this.Controls.Add(this.relay_on11);
            this.Controls.Add(this.relay_off16);
            this.Controls.Add(this.relay_off15);
            this.Controls.Add(this.relay_off14);
            this.Controls.Add(this.relay_off13);
            this.Controls.Add(this.relay_off12);
            this.Controls.Add(this.relay_off11);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.penghitung_waktu);
            this.Controls.Add(this.jam);
            this.Controls.Add(this.tombol_10);
            this.Controls.Add(this.tombol_9);
            this.Controls.Add(this.tombol_8);
            this.Controls.Add(this.tombol_7);
            this.Controls.Add(this.tombol_6);
            this.Controls.Add(this.tombol_5);
            this.Controls.Add(this.tombol_4);
            this.Controls.Add(this.tombol_3);
            this.Controls.Add(this.tombol_2);
            this.Controls.Add(this.tombol_1);
            this.Controls.Add(this.relay_on10);
            this.Controls.Add(this.relay_on9);
            this.Controls.Add(this.relay_on8);
            this.Controls.Add(this.relay_on7);
            this.Controls.Add(this.relay_on6);
            this.Controls.Add(this.relay_on5);
            this.Controls.Add(this.relay_on4);
            this.Controls.Add(this.relay_on3);
            this.Controls.Add(this.relay_on2);
            this.Controls.Add(this.relay_on1);
            this.Controls.Add(this.relay_off10);
            this.Controls.Add(this.relay_off9);
            this.Controls.Add(this.relay_off8);
            this.Controls.Add(this.relay_off7);
            this.Controls.Add(this.relay_off6);
            this.Controls.Add(this.relay_off5);
            this.Controls.Add(this.relay_off4);
            this.Controls.Add(this.relay_off3);
            this.Controls.Add(this.relay_off2);
            this.Controls.Add(this.relay_off1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.chart2);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Battery Tester";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label relay_off1;
        private System.Windows.Forms.Label relay_off2;
        private System.Windows.Forms.Label relay_off3;
        private System.Windows.Forms.Label relay_off4;
        private System.Windows.Forms.Label relay_off5;
        private System.Windows.Forms.Label relay_off6;
        private System.Windows.Forms.Label relay_off7;
        private System.Windows.Forms.Label relay_off8;
        private System.Windows.Forms.Label relay_off9;
        private System.Windows.Forms.Label relay_off10;
        private System.Windows.Forms.Label relay_on1;
        private System.Windows.Forms.Label relay_on2;
        private System.Windows.Forms.Label relay_on3;
        private System.Windows.Forms.Label relay_on4;
        private System.Windows.Forms.Label relay_on5;
        private System.Windows.Forms.Label relay_on6;
        private System.Windows.Forms.Label relay_on7;
        private System.Windows.Forms.Label relay_on8;
        private System.Windows.Forms.Label relay_on9;
        private System.Windows.Forms.Label relay_on10;
        private System.Windows.Forms.Label tombol_1;
        private System.Windows.Forms.Label tombol_2;
        private System.Windows.Forms.Label tombol_3;
        private System.Windows.Forms.Label tombol_4;
        private System.Windows.Forms.Label tombol_5;
        private System.Windows.Forms.Label tombol_6;
        private System.Windows.Forms.Label tombol_7;
        private System.Windows.Forms.Label tombol_8;
        private System.Windows.Forms.Label tombol_9;
        private System.Windows.Forms.Label tombol_10;
        private System.Windows.Forms.Timer timer1 = null;
        private System.Windows.Forms.Label jam;
        private System.Windows.Forms.Label penghitung_waktu;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label relay_off11;
        private System.Windows.Forms.Label relay_off12;
        private System.Windows.Forms.Label relay_off13;
        private System.Windows.Forms.Label relay_off14;
        private System.Windows.Forms.Label relay_off15;
        private System.Windows.Forms.Label relay_off16;
        private System.Windows.Forms.Label relay_on11;
        private System.Windows.Forms.Label relay_on12;
        private System.Windows.Forms.Label relay_on13;
        private System.Windows.Forms.Label relay_on14;
        private System.Windows.Forms.Label relay_on15;
        private System.Windows.Forms.Label relay_on16;
        private System.Windows.Forms.Label tombol_11;
        private System.Windows.Forms.Label tombol_12;
        private System.Windows.Forms.Label tombol_13;
        private System.Windows.Forms.Label tombol_14;
        private System.Windows.Forms.Label tombol_15;
        private System.Windows.Forms.Label tombol_16;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label status_relay1;
        private System.Windows.Forms.Label status_relay2;
        private System.Windows.Forms.Label status_relay3;
        private System.Windows.Forms.Label status_relay4;
        private System.Windows.Forms.Label status_relay5;
        private System.Windows.Forms.Label status_relay6;
        private System.Windows.Forms.Label status_relay7;
        private System.Windows.Forms.Label status_relay8;
        private System.Windows.Forms.Label status_relay9;
        private System.Windows.Forms.Label status_relay10;
        private System.Windows.Forms.Label status_relay11;
        private System.Windows.Forms.Label status_relay12;
        private System.Windows.Forms.Label status_relay13;
        private System.Windows.Forms.Label status_relay14;
        private System.Windows.Forms.Label status_relay15;
        private System.Windows.Forms.Label status_relay16;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.IO.Ports.SerialPort serialPort1;
        private TextBox namaPath;
        private Label label25;
        private Label close_program;
        private Label label26;
        private Label label27;
        private TextBox namaFile;
        private Label waktu_berjalan;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart3;
        private Label label28;
        private Label label29;
        private ComboBox comboBox2;
        private Label label30;
        private Label label31;
        private Button button5;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private RadioButton radioButton3;
        private Label label32;
        private Button button4;
        private Button button6;
        private Button button7;
        private Button button8;
    }
}

